function throwStringError() {
    throw 'stringError';
}

throwStringError();
