function throwRealError() {
    throw new Error('realError');
}

throwRealError();
