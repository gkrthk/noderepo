import { Component,ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: 'app/app.component.html'  
})
export class AppComponent  { 
	name = 'Angular'; 
	counterValue = 5;
}
