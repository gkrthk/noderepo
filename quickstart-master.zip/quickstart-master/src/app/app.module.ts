import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CustomCounterComponent } from './custom-counter.component';
import { AppComponent }  from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, CustomCounterComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
